package com.kh.a_string;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringConcatenation sc = new StringConcatenation();
		//sc.stringconcatenation();
		//sc.stringBuilderConcat();
		//sc.stringBufferConcat();
		
		StringMethod sm = new StringMethod();
		//sm.testMethod();
		
		StringSplit ss = new StringSplit();
		ss.splitTest();
	}

}
