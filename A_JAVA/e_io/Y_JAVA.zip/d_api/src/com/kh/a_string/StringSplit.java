package com.kh.a_string;

import java.util.Arrays;
import java.util.StringTokenizer;

public class StringSplit {
	
	public void splitTest() {
		
		//String.split
		String str = "boo:and:foo";
		String[] result = str.split(":");
		System.out.println(Arrays.toString(result));
		
		System.out.println("==========================");
		
		//StringTokenizer안에 토큰이 남았는지를 검사
		StringTokenizer st = new StringTokenizer("this is a test");
		while(st.hasMoreTokens()) {
			//다음 토큰을 반환
			System.out.println(st.nextToken());
		}
		System.out.println("==========================");
		
		//StringTokenizer안에 토큰이 남았는지를 검사
		StringTokenizer st2 = new StringTokenizer("this is a test","t",true);
		while(st2.hasMoreTokens()) {
			//다음 토큰을 반환
			System.out.println(st2.nextToken());
		}
	}
}
