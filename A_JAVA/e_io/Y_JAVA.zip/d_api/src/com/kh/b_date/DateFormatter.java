package com.kh.b_date;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateFormatter {
	//SimpleDateFormat 사용하면 편하다
	public void formatterrTest() {
		
		Calendar today = Calendar.getInstance();
		
		//원하는 포맷으로 시간 출력하기
		//SimpleDateFormat의 생성자 매개변수에 포맷을 작성해서 전달
		SimpleDateFormat sdf = new SimpleDateFormat(
				"\n오늘은 yyyy년 MM월 dd일  E요일 hh시 mm분 ss초"
				);
		boolean result = true;
		
		System.out.println(sdf.format(today.getTime()));
			
		
	}
}
