package com.kh.c_collection.a_list.simple;

import java.util.LinkedList;

import com.kh.c_collection.model.vo.Music;

public class Run {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleLinkedList<Music> list = new SimpleLinkedList<>();
		//SimpleList<Music> list = new SimpleList<Music>();
		
		
		list.add(new Music("Dok2","On My Way"));
		list.add(new Music("김경호","금지된 사랑"));
		list.add(new Music("오마이걸","Dolphin"));
		list.add(new Music("나훈아","태스형"));
		for (Music music : list) {
			System.out.println(music);
		}
		System.out.println("");
		
		list.remove(2);
		System.out.println("2번인덱스 삭제");
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		System.out.println("");
		System.out.println("for:each문");
		
		for (Music music : list) {
			System.out.println(music);
		}
		

	}
}
