package com.kh.c_collection.a_list;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListTest lt = new ListTest();
		lt.doList();
	}
	
}
