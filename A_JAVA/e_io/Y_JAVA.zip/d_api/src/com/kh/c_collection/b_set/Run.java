package com.kh.c_collection.b_set;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SetTest st = new SetTest();
		//st.doSet();
		SetPractice sp = new SetPractice();
		sp.setPractice();

	}

}
