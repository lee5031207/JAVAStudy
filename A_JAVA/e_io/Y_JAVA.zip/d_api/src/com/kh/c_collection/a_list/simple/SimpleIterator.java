package com.kh.c_collection.a_list.simple;

import java.util.Iterator;

public class SimpleIterator<E> implements Iterator<E> {

	private Object[] simpleList;
	private int size;
	//Iterator가 잃은 데이터의 개수를 저장할 변수
	private int iterIdx;
	
	
	public SimpleIterator(Object[] simpleList, int size) {
		super();
		this.simpleList = simpleList;
		this.size = size;
	}
	
	@Override
	public boolean hasNext() {
		//iterIdx (next()로 반환한 요소의 개수)가 size보다 작으면 true
		System.out.println("hasnext 메서드호출");
		if(iterIdx < size) {
			return true;
		}
		return false;
	}

	@Override
	public E next() {
		System.out.println("next 메서드 호출");
		E res = (E) simpleList[iterIdx];
		iterIdx++;
		return res;
	}
	
}
