package com.kh.c_collection.a_list.simple;

import java.util.Iterator;

//Generic : 클래스 내부에서 사용하는 타입을 외부에서 결정하는 것
// 			인스턴스화 할 때 타입이 결정
// 			클래스명 뒤에 <E> 와 같은 형태로 Generic을 지정
//			Generic은 어떤 알파벳으로든 지정할 수가 있지만, 주로 아래의 알파벳이 많이 사용
//E(Element) : 배열 기반의 구조에서 generic을 사용할때 주로 E로 사용
//T(Type) : 일반적인 type을 의미 
//K(Key) : Map에서 key를 의미 
//V(Value) : Map에서 Value를 의미

//Generic을 선언할 때 외부에서 지정할 Generic 타입에 제한을 걸 수 있다.
//<? extends List> List의 후손 타입만 Generic으로 지정이 가능
//<? super List> 
public class SimpleList<E> implements Iterable<E>{
	
	//데이터를 저장할 Object 배열
	private Object[] simpleList;
	
	//이 배열의 초기 크기를 결정해야함
	private int arraySize = 10;
	
	//배열안에 저장된 요소의 개수
	private int size = 0;
	
	//기본 생성자로 SimpleLiset를 생성할 경우 Object배열은 기본값(10)으로
	public SimpleList() {
		simpleList = new Object[arraySize];
	}
	//매개변수로 넘어온 크기로 Object배열을 생성
	public SimpleList(int arraySize) {
		simpleList =  new Object[arraySize];
	}
	
	//size() : 리스트에 저장된 요소드르이 개수를 반환하는 메서드
	public int size() {		
		return size;
	}
	
	
	//1. add
	public void add(E data) {
		//현재 배열이 꽉 차지 않은 경우
		if(size < arraySize) {
			simpleList[size] = data;
		}else {//현재 배열이 꽉 찬 경우
			//배열의 크기를 두배 확장
			arraySize *= 2;
			Object[] tempArr = new Object[arraySize];
			for(int i=0; i<simpleList.length; i++) {
				tempArr[i] = simpleList[i]; 
			}
			tempArr[size] = data;
			simpleList = tempArr;
		}
		size++;
	}
	//2. get
	public E get(int index) {
		if(index < size) {
			return (E)simpleList[index];			
		}else {
			//예외가 발생하면 메서드를 탈출
			throw new ArrayIndexOutOfBoundsException("인덱스의 범위를 초과했습니다.");
		}  
	}
	//3. set
	public E set(int index, E data) {
		//수정 전에 미리 수정 될 요소를 저장
		E res = (E)simpleList[index];
		//수정
		simpleList[index] = data;
		return res;
	}
	
	//4. remove
	
	public E remove(int index) {
		E res = (E)simpleList[index];
		for(int i=0; i<size-1; i++) {
			if(i >= index) {
				simpleList[i] = simpleList[i+1];
			}
		}
		//마지막 인덱스를 null을 채워준다
		simpleList[size-1] = null;
		size--;
		return res;
	}
	
	
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		System.out.println("Iterator 메서드 호출");
		return new SimpleIterator<E>();
	}
	//내부클래스(Inner Class/Member Calss)
	//클래스 안에 클래스를 선언 할 수 있다. 외부 클래스의 필드를 공유 한다.
	private class SimpleIterator<E> implements Iterator<E> {
		//Iterator가 잃은 데이터의 개수를 저장할 변수
		private int iterIdx;
		
		@Override
		public boolean hasNext() {
			//iterIdx (next()로 반환한 요소의 개수)가 size보다 작으면 true
			System.out.println("hasnext 메서드호출");
			//System.out.println("iterIdx : "+iterIdx);
			if(iterIdx < size) {
				return true;
			}
			return false;
		}

		@Override
		public E next() {
			System.out.println("next 메서드 호출");
			//System.out.println("iterIdx : "+iterIdx);
			E res = (E) simpleList[iterIdx];
			iterIdx++;
			return res;
		}
		
	}
}
