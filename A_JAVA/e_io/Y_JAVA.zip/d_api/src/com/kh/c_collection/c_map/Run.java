package com.kh.c_collection.c_map;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapTest mt = new MapTest();
		mt.doMap();
	}

}
