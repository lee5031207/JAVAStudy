package com.kh.a_runtimeException;

import javax.swing.text.html.HTMLDocument.RunElement;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RuntimeException re = new RuntimeException();
		re.classNArrayEx();
	}

}
