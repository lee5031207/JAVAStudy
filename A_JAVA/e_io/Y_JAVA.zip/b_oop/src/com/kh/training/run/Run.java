package com.kh.training.run;

import com.kh.training.view.MainMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainMenu().mainMenu();
	}

}
