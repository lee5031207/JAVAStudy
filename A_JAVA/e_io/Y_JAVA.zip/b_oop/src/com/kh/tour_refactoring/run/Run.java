package com.kh.tour_refactoring.run;

import com.kh.tour.view.MainMenu;

public class Run {
	public static void main(String[] args) {
		
		new com.kh.tour_refactoring.view.MainMenu().mainMenu();
	}
}
