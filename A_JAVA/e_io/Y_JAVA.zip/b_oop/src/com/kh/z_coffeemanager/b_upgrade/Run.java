package com.kh.z_coffeemanager.b_upgrade;

public class Run {
	public static void main(String[] args) {
		new Menu().showIndex();
	}
}
