package com.kh.z_coffeemanager.a_encapsulation;

public class Run {
	public static void main(String[] args) {
		new Menu().showIndex();
	}
}
