package com.kh.z_coffeemanager.d_polymorphism;

public class Run {
	public static void main(String[] args) {
		new Menu().showIndex();
	}
}
