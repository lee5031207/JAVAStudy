package skillup.day03.library.run;

import skillup.day03.library.view.LibraryMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LibraryMenu().mainMenu();
	}

}
