package skillup.day04.silsub.model.vo;

public class GalaxyNote9 extends SmartPhone{

	@Override
	public void printMaker() {
		// TODO Auto-generated method stub
		System.out.println("갤럭시 노트9은 삼성에서 만들어 졌다.");
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("고속 충전, 고속 무선 충전");	
	}

	@Override
	public void picture() {
		// TODO Auto-generated method stub
		System.out.println("1300만 듀얼 카메라");
	}

	@Override
	public void touch() {
		// TODO Auto-generated method stub
		System.out.println("정전식 ,와콤펜 지원");	
	}
	
	

	
	
	
	
}
