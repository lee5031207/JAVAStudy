package skillup.day04.silsub.model.vo;

public interface TouchDisplay {
	void touch(); //터치방식
}
