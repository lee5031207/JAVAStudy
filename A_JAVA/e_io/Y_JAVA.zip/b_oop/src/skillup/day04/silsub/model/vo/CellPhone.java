package skillup.day04.silsub.model.vo;

public interface CellPhone extends Phone,Camera{
	void charge(); //충전 방식
	
	
}
