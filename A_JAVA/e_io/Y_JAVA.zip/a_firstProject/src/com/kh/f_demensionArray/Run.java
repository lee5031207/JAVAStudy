package com.kh.f_demensionArray;

public class Run {

	public static void main(String[] args) {
		DemensionArray testArr = new DemensionArray();
		//testArr.testDemensionArray2();
		
		DemensionArrayPrac testPrac = new DemensionArrayPrac();
		testPrac.quize2();
	}
}
