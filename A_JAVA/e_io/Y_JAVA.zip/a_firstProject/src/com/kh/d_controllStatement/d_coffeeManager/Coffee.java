package com.kh.d_controllStatement.d_coffeeManager;

import java.util.*;

public class Coffee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		
	}
	

}
