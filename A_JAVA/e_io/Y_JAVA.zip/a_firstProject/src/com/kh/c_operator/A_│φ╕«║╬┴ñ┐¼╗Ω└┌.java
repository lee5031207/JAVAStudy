package com.kh.c_operator;

public class A_논리부정연산자 {
	public static void main(String[] args) {
		
		// 논리부정연산자 : !
		// 논리값을 반대로 바꾸는 연산자 : true -> false, false -> true
		System.out.println("true의 부정 : " + !true);
		System.out.println("false의 부정 : " + !false);
		
	}
}
