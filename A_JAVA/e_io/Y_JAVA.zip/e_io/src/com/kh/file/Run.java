package com.kh.file;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		B_FileIO fio = new B_FileIO();
		fio.fileInOut();
	}

}
