package com.kh.file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class B_FileIO {

	Scanner sc = new Scanner(System.in);
	
	public void fileInOut() {
		System.out.print("읽어올 자원의 경로를 입력하세요 >>");
		String url = sc.nextLine();
		System.out.print("저장할 파일명을 입력하세요 >>");
		String filename = sc.nextLine();
		
		FileInputStream fis = null;
		FileOutputStream fos  = null;
		
		//파일 저장에 걸리는 시간을 측정
		System.out.println("NoBuffer :" + System.currentTimeMillis());
		
		try {
			fis = new FileInputStream(url);
			fos = new FileOutputStream(filename);
			
			int check = 0;
			while(check != -1) {
				check = fis.read();
				fos.write(check);
			}
		System.out.println("NoBuffer :" + System.currentTimeMillis());
		
		} catch (FileNotFoundException e) {			 
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}		
	}//fileInOut()끝
}
