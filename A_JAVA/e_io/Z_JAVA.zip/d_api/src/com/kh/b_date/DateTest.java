package com.kh.b_date;

import java.time.Month;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateTest {

	public void date() {
		
		//1. Date
		// Date클래스에서 년도에는 1900을 월에는 1을 더해서 출력
		// 초기에 급하게 개발되어 완성도가 낮아 가능하면 Calendar클래스 사용
		Date today = new Date();
		System.out.println(today);
		
		System.out.println(1900+today.getYear()+"년");
		System.out.println(1+today.getMonth()+"월");
		System.out.println(today.getDate()+"일");
		System.out.println(today.getHours()+"시");
		System.out.println(today.getMinutes()+"분");
		System.out.println(today.getSeconds()+"초");
		
		
	}
	
	public void calendarTest() {
		// 2.Calendar
		// TimeZone 기능 제공
		// GMT를 기준으로 지역의 시간이 몇시간 빠른지 느린지 표시.
		// 한국은 GMT+9
		// TimeZone은 ST,DST로 나누어 표기
		// ST : 일반 시간 계산 방법
		// DST : 일광 절약 시간제
		// KST, KDT 이런식으로 타임존 표시
		Calendar calendar = Calendar.getInstance();
		System.out.println("그레고리알캘린더의 인스턴스 입니까? " +
				(calendar instanceof GregorianCalendar));
		
		System.out.println(calendar.get(calendar.YEAR));
		System.out.println(calendar.get(calendar.MONTH)+1);
		System.out.println(calendar.get(calendar.DATE));
		System.out.println(calendar.get(calendar.HOUR));
		System.out.println(calendar.get(calendar.MINUTE));
		System.out.println(calendar.get(calendar.SECOND));
		
		//set() : 원하는 시간으로 Calendar 인스턴스를 세팅
		calendar.set(2020,9,27,5,42,39);
		System.out.println("=====================");
		//getTime() : calendar 인스턴스에 세팅된 시간을 가지는  Date인스턴스 반환
		System.out.println(calendar.getTime());
		

	}
	
}
