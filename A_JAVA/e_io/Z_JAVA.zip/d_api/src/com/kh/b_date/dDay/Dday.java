package com.kh.b_date.dDay;

import java.util.Calendar;

public class Dday {

	
	public long dDay(int year, int month, int date) {
		long between = 0 ;
		
		Calendar today = Calendar.getInstance();
		long todayM = today.getTimeInMillis()/1000;
		Calendar dday = Calendar.getInstance();
		dday.set(year, month-1, date);
		long ddayM = dday.getTimeInMillis()/1000;
		
		between = (ddayM-todayM)/60/60/24;
		System.out.println(todayM);
		System.out.println(ddayM);
	
		return between;
		
		//과거날짜 넣으면 마이너스로 출력
	}
}
