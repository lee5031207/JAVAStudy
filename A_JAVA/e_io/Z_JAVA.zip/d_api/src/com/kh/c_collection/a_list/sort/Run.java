package com.kh.c_collection.a_list.sort;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;

import com.kh.c_collection.a_list.comparator.AgeComparator;

import java.util.Collections;

public class Run {

	public static void main(String[] args) {
		
		List<Student> studentList = new ArrayList<>();
		
		studentList.add(new Student("박준범", 20));
		studentList.add(new Student("박준범", 18));
		studentList.add(new Student("박준범", 22));
		studentList.add(new Student("박준범", 17));
		studentList.add(new Student("김준범", 19));
		studentList.add(new Student("이준범", 20));
		studentList.add(new Student("이준범", 24));
		studentList.add(new Student("김준범", 26));
		
		for (Student student : studentList) {
			System.out.println(student);
		}
		//1. list 정렬
		Collections.sort(studentList);
		System.out.println("==========Collections.sort정렬==========");
		for (Student student : studentList) {
			System.out.println(student);
		}
		
		//Collecction.sort()메서드를 활용해 정렬을 하되
		//기본적으로  이름 오름차순으로 정렬		
		//이름이 같은 동명이인이 존재하면 나이 내림차순
		
		//2.list인터페이스의 sort메서드를 활용
		studentList.sort(new AgeComparator());
		System.out.println("==========정렬==========");
		for (Student student : studentList) {
			System.out.println(student);
		}
		
		String text ="'TDCNS'는 Traffic Data Collection and Service의 약자로,\r\n" + 
				"초소형 컴퓨터 젯슨나노 모듈과 카메라를 교차로에 설치해 카메라로 교통 영상을 수집하고 \r\n" + 
				"라이브 영상에서 차량을 인식하고 분석해 교통량 데이터를 제작하며\r\n" + 
				"제작한 이 데이터를 활용해 새로운 서비스까지 제공하는 All in One 솔루션입니다.";
		
		System.out.println(text.length());
		
		
	
	}
}
