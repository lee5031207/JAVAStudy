package com.kh.c_collection.c_map.simple;

import java.util.HashSet;
import java.util.Set;

public class SimpleMap<K,V> {
	
	int arraySize =17;
	Object[] simpleMap;
	Set<K> KeySet = new HashSet<K>();
	
	public SimpleMap() {
		this.simpleMap = new Object[arraySize];		
	}
	
	public SimpleMap(int arraySize) {
		this.arraySize = arraySize;
		this.simpleMap = new Object[arraySize];
	}
	
	//hash함수
	private int simpleHashMethod(K key) {
		int res = Math.abs(key.hashCode());
		res %= arraySize;		
		return res;		
	}
	
	//put
	
	//get
	
	//remove
	
	//KeySet
}
