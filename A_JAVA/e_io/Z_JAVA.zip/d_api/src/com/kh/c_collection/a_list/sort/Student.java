package com.kh.c_collection.a_list.sort;

import java.util.Comparator;

//Complarable : 비교가 가능한 클래스 
public class Student implements Comparable<Student> {

	private String name;
	private int age;
	
	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + "]";
	}


	//인터페이스에서 오버라이드 해야 하는 함수 
	@Override
	public int compareTo(Student o) {
		//나이 비교
		//이 인스턴스의 나이가 매개변수로 넘어온 인스턴스의 나이보다 
		//크면 양수, 작으면 음수, 같으면 0  -> 오름차순
		//return this.age - o.getAge();
		
		if(this.name == o.getName()) {
			return o.getAge()-this.age;
		}
		//이름 사전순 비교
		//String의 CompareTo 메서드 이용해 비교
		return this.name.compareTo(o.getName());
	}



	
	
	
	
	
	
}
