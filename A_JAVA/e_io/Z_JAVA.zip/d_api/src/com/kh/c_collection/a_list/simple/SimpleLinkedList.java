package com.kh.c_collection.a_list.simple;

import java.util.Iterator;
import java.util.NoSuchElementException;

import com.kh.c_collection.a_list.simple.node.Node;

public class SimpleLinkedList<E> implements Iterable<E> {

	private Node<E> head; //첫 노드를 저장
	private Node<E> moveLink; //노드간 이동용 레퍼런스
	private int nodeCount; //노드의 개수
	
	public SimpleLinkedList() {
		
	}
	
	//size함수
	public int size() {
		return nodeCount;
	}
	
	//add
	public void add(E data) {
		// node를 생성해 사용자가 입력한 데이터를 넘겨준다
		Node node = new Node(data);
		if(head == null && nodeCount==0) {
			head = node;
		}else {
			moveLink = head;
			for(int i=0; i<nodeCount-1; i++) {
				//moveLink에  moveLink에 담겨있던 노드의 담은 노드를 저장
				moveLink = moveLink.getLink();
				//1. head의 링크를 넣어줌
				//2. 2노드의 링크
				//3. 3노드의 링크 ~~~				
			}
			//마지막 노드 링크에 새 주소 저장
			moveLink.setLink(node);
		}
		nodeCount++;
	}
	
	//get
	public E get(int index) {
		moveLink = head;
		for(int i=0; i<index; i++) {
			moveLink = moveLink.getLink();
		}		
		return moveLink.getData();
	}
	
	
	//set
	public E set(int index, E data) {
		E res = null;
		moveLink = head;
		for(int i=0; i<index; i++) {
			moveLink = moveLink.getLink();
		}
		res = moveLink.getData();
		moveLink.setData(data);	
		return res;
	}
	
	//remove
	//삭제는 삭제할 노드의 앞 노드를 찾아 다다음노드의 주소를 링크에 넣어주면댐
	public E remove(int index) {
		E res = null;
		moveLink = head;
		if(index==0) {
			//head에 두번째 노드를 저장하면댐
			res = head.getData();
			head = head.getLink();
		}else {
			for(int i=0; i<index-1; i++) {
				moveLink = moveLink.getLink();
			}
			res = moveLink.getLink().getData();
			moveLink.setLink(moveLink.getLink().getLink());		
		}
		nodeCount--;
		return res;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new SimpleLinkedIterator<E>();
	}
	//내부 클래스
	public class SimpleLinkedIterator<E> implements Iterator<E>{
		
		private int iterIdx;
		
		{
			moveLink = head;
		}
		
		//iterIdx (next()로 반환한 요소의 개수)가 size보다 작으면 true
		@Override
		public boolean hasNext() {
			if(iterIdx < nodeCount) {
				return true;
			}
			return false;
		}
		@Override
		public E next() {	
			E res = (E) moveLink.getData();
			moveLink = moveLink.getLink();
			iterIdx++;
			return res;
		}
	}
}
