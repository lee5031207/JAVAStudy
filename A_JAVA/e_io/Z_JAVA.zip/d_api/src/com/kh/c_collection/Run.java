package com.kh.c_collection;

import com.kh.c_collection.a_list.ListTest;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ListTest lt = new ListTest();
		lt.doList();
	}

}
