package com.kh.a_string;

public class StringConcatenation {
	
	//String은 값을 수정할 수 없는 불변객체이다. immutable객체이다.
	//String의 값을 수정할 경우,
	//해당 인스턴스가 변경되는 것이 아니라 새로운 인스턴스를 만든다.
	//String을 자주 수정하게 되면 메모리 공간을 비효율적으로 사용하게 된다.
	
	public void stringconcatenation() {
		String test ="JAVA";
		System.out.println("수정 전 주소 : "+ System.identityHashCode(test));
		System.out.println(test);
		test += "Class";
		System.out.println("수정 후 주소 : "+ System.identityHashCode(test));
		System.out.println(test);
		
		test = test.concat(" Easy");
		System.out.println("concat : "+ System.identityHashCode(test));
		System.out.println("test");
	}
	
	//문자열 값을 수정하는 mutable 객체.
	//내부적으로 기본 16문자 크기의 buffer를 사용하고, 이  buffer의 크기를 조정할 수 있다.
	//쓰레드 동기화를 지원하지 않는다.
	public void stringBuilderConcat() {
		
		StringBuilder builder = new StringBuilder("ABC");
		System.out.println("결합 전 : " +System.identityHashCode(builder));
		
		//append(String s) : 문자열 결합 함수
		builder.append("DEFG");
		System.out.println("결합 후 : " +System.identityHashCode(builder));
		System.out.println(builder);

	}
	// 문자열 값을 수정하는 mutable 객체
	// 기본 16문자 크기의 buffer를 사용
	// 쓰레드 동기화를 지원, 속도가 stringbuilder보다 느리지만 유의미하지 않아
	// StringBuffer를 더욱 자주 사용한다.	
	public void stringBufferConcat() {
		
		StringBuffer buffer = new StringBuffer("ABC");
		System.out.println("결합 전 : " +System.identityHashCode(buffer));
		
		buffer.append("DEFG");
		System.out.println("결합 후 : " +System.identityHashCode(buffer));
		System.out.println(buffer);
		
	}
	
}
 