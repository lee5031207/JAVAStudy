package com.kh.test;

public class ValueTest {
	public static void main(String[] args) {
		System.out.println("이름 : 하명도");
		System.out.println("성별 :  남");
	}
}
