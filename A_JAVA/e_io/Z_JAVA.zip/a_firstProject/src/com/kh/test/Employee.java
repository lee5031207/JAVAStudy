package com.kh.test;

public class Employee {
	String[] empArr = {
			"2014030577, 홍길동, 개발, 대리, 380",
			"2017112033, 김유신, 기획, 주임, 320",
			"2019122588, 유관순, 회계, 사원, 280"
	};
}
