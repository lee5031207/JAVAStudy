package com.kh.f_array;

import java.util.Arrays;
import com.kh.f_array.study.A_array;
import com.kh.f_array.study.ArrayUtil;

public class Run {

	public static void main(String[] args) {
		A_array test = new A_array();
		//test.testArray6();
		
		ArrayUtil util = new ArrayUtil();

		int a[] = {1,2,3,4,5,6,7,8};
		int b[] = {4,5,6};		
//		int result[] = util.addAll(a, b);		
//		System.out.println(Arrays.toString(result));
		
//		int result[] = util.subArr(a, 0, 4);
//		System.out.println(Arrays.toString(result));
		
//		int result[] = util.remove(a, 5);
//		System.out.println(Arrays.toString(result));
//		System.out.println(result.length);
		
		
	}
}
