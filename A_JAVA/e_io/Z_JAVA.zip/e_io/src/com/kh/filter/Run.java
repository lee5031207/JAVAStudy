package com.kh.filter;

public class Run {

	public static void main(String[] args) {
		A_BufferedIO bio = new A_BufferedIO();
		bio.bufferedWithFile();
	}

}
