package skillup.day04.silsub.model.vo;

public class V40 extends SmartPhone{

	@Override
	public void printMaker() {
		// TODO Auto-generated method stub
		System.out.println("V40은 LG에서 만들어 졌다.");
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("고속충전");	
	}

	@Override
	public void picture() {
		// TODO Auto-generated method stub
		System.out.println("1200, 1600만 화소 트리플 카메라");
	}

	@Override
	public void touch() {
		// TODO Auto-generated method stub
		System.out.println("정전식");	
	}

	
}
