package skillup.day04.silsub.model.vo;

public interface Camera {
	void picture();
}
