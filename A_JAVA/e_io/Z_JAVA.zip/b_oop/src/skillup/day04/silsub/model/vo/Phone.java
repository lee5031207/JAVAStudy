package skillup.day04.silsub.model.vo;

public interface Phone {
	void makeacall(); //전화걸기
	void takeacall(); //전화받기
}
