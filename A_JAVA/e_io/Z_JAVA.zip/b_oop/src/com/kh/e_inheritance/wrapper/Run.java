package com.kh.e_inheritance.wrapper;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WrapperClass wc = new WrapperClass();
		//wc.printVarSize();
		wc.parse();
	}

}
