package com.kh.a_encapsulation.method_encapsulation;

public class Run {

	public static void main(String[] args) {
		SpringConcert test = new SpringConcert();
		test.startConcert();
	}
}
