package com.kh.c_init;

public class Run {
	public static void main(String[] args) {
		Constructor constructor = new Constructor();
		System.out.println(constructor.getMemberStr());
		System.out.println(Constructor.getClassInt());
	}
}
