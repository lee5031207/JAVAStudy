package com.kh.z_coffeemanager.c_upgrade2;

public class Run {
	public static void main(String[] args) {
		new Menu().showIndex();
	}
}
