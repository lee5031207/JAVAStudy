package com.kh.h_interface;

public interface CommunicationAvailable {
	void sendMessage();
}
