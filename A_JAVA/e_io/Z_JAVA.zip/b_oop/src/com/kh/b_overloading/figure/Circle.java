package com.kh.b_overloading.figure;

public class Circle {
	
	//원의 반지름
	private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
}
