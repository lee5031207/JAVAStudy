package com.kh.g_abstract.sports;

public class BasketBall extends Sports {

	@Override
	public void rule() {
		// TODO Auto-generated method stub
		System.out.println("농구는 공을 발로 차면 안됩니다.");
	}

}
