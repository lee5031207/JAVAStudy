package com.kh.g_abstract.sports;

public class FootBall extends Sports{

	@Override
	public void rule() {
		// TODO Auto-generated method stub
		System.out.println("축구는 공을 손으로 만지면 안됩니다");
	}

}
